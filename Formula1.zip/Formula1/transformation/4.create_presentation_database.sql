-- Databricks notebook source
CREATE DATABASE IF NOT EXISTS f1_presentation
LOCATION "/mnt/formula1adl/presentation"

-- COMMAND ----------

desc database f1_presentation

-- COMMAND ----------

