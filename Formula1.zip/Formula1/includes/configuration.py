# Databricks notebook source
raw_folder_path='/mnt/forumla1adl/raw'
processed_folder_path='/mnt/formula1adl/processed'
presentation_folder_path='/mnt/formula1adl/presentation'

# COMMAND ----------

