-- Databricks notebook source
-- MAGIC %md
-- MAGIC #### Lesson objectives
-- MAGIC 1. Spark SQL Documentation
-- MAGIC 1. Create Database demo
-- MAGIC 1. Data tab in the UI
-- MAGIC 1. SHOW command
-- MAGIC 1. DESCRIBE command
-- MAGIC 1. Find the current database

-- COMMAND ----------

create database if not exists demo;

-- COMMAND ----------

show databases


-- COMMAND ----------

describe database extended demo

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### learning objectives
-- MAGIC 1. Create managed tables using python
-- MAGIC 1. Create managed tables using SQL
-- MAGIC 1. Effect of dropping a managed table
-- MAGIC 1. Describe table

-- COMMAND ----------

-- MAGIC %run "../includes/configuration"

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df=spark.read.parquet(f"{presentation_folder_path}/race_results")

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df.write.format("parquet").saveAsTable("demo.race_results_python")

-- COMMAND ----------

create table race_results_sql as select * from demo.race_results_python where race_year=2020

-- COMMAND ----------

drop table race_results_sql

-- COMMAND ----------

-- MAGIC %md
-- MAGIC #### Learning objectives
-- MAGIC 1. Create external tables using Python
-- MAGIC 1. Create external tables using SQL
-- MAGIC 1. Effect of dropping an External table

-- COMMAND ----------

-- MAGIC %python
-- MAGIC race_results_df.write.format("parquet").option("path", f"{presentation_folder_path}/race_resuts_ext_py").saveAsTable("demo.race_results_ext_py")

-- COMMAND ----------

describe extended demo.race_results_ext_py

-- COMMAND ----------

select current_database()

-- COMMAND ----------

show tables

-- COMMAND ----------

create temp view v_race_results 
as
select * from demo.race_results_python where race_year=2018

-- COMMAND ----------

select * from v_race_results

-- COMMAND ----------

create global temp view gv_race_results 
as
select * from demo.race_results_python where race_year=2012


-- COMMAND ----------

select * from global_temp.gv_race_results

-- COMMAND ----------

create or replace view gv_race_results 
as
select * from demo.race_results_python where race_year=2000


-- COMMAND ----------

