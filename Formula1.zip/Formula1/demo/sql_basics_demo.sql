-- Databricks notebook source
show databases

-- COMMAND ----------

use f1_processed

-- COMMAND ----------

show tables

-- COMMAND ----------

select * from drivers limit where nationality='British'

-- COMMAND ----------

